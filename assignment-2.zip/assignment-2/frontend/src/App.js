import axios from 'axios';
import React, { useEffect, useState } from 'react';



function App() {
const [number,setNumber] = useState([]);
const [setData,onsetData] = useState({
    Name:"",
    Department:"",
    Salary:"",
  });
  useEffect(()=>{
    fetchAllUser();
    total();
  },[]);
  const [userData,setUserData]=useState([]);
   async function fetchAllUser(){
    const data= await axios.get("http://localhost:3001/read");
    console.log("This is the stored data",data.data);
    setUserData(data.data);
  }
  async function total(){
    const Total = await axios.get("http://localhost:3001/sum");
    console.log("Total:",Total);
    console.log("Total:",Total.data.totalSalary);
    console.log("Total:",Total.data[0].totalSalary);
    setNumber(Total.data[0].totalSalary);
    console.log(number);
  }
  const handleChange=(e)=>{
    const {name,value} = e.target;
    onsetData({
      ...setData,
      [name]:value,
    });
  
  }
  const submitData= async(e)=>{
   e.preventDefault();
   console.log("Inputted data",setData)
   const Response=  await axios.post("http://localhost:3001/create",setData,
    {headers:{"Content-Type": "application/json"}});
   console.log("Data is stored" ,Response );
  }
  const handleDelete = async(id)=>{
  const res = axios.delete(`http://localhost:3001/delete/${id}`);
  if(res.status === 200){
    fetchAllUser();
  }
  }
  return (
    <>
    <form onSubmit={submitData}>
      <label>Employee Name</label><br></br>
      <input type="text" value={setData.Name} name="Name" onChange={handleChange}></input><br></br>
      <label>Department</label><br></br>
      <input type="text" value={setData.Department} name="Department" onChange={handleChange}></input><br></br>
      <label>Salary</label><br></br>
      <input type="text" value={setData.Salary} name="Salary" onChange={handleChange}></input><br></br>
      <button type="Submit">Add</button>
    </form>
    <div className="">
      <table>
        <thead>
          <tr>
            <th>S.No</th>
            <th>Name</th>
            <th>Department</th>
            <th>Salary</th> 
          </tr>
        </thead>
        <tbody>
          {userData.map((item,i)=>(
            <tr>
              <td >{i+1}</td>
              <td>{item?.Name}</td>
              <td>{item?.Department}</td>
              <td>{item?.Salary}</td>
              <td>
              <button onClick={()=>handleDelete(`${item._id}`)}>Delete</button></td>
             
            </tr>

          ))}
        </tbody>
      </table>
      </div>
      <h1>the total salary of all the employee are {number}</h1>
    </>

  );
}

export default App;
